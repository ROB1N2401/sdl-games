#include "ShieldsManager.h"

ShieldsManager::ShieldsManager()
{
}

void ShieldsManager::Initialize(Image& spritesheetImage_in)
{
}

void ShieldsManager::Render(RenderManager& renderManager)
{
}
